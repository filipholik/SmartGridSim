<?php
    $db = new SQLite3('SGData.db');
?>